import torchaudio as ta
from chatterbox.tts import ChatterboxTTS

# Model load karo
model = ChatterboxTTS.from_pretrained(device="cpu")  # Agar GPU hai to "cuda" daalo
text = "Hello, this is a test of my cloned voice. It sounds just like me!"
audio_prompt_path = "path/to/output.wav"  # Apni WAV file ka path daalo

# Generate cloned voice
wav = model.generate(text, audio_prompt_path=audio_prompt_path)

# Save output
ta.save("cloned_output.wav", wav, model.sr)