from bark import generate_audio, SAMPLE_RATE
from scipy.io.wavfile import write
import time

print("Starting audio generation...")
text = "Hello, yeh Bark ka test hai."
start_time = time.time()
print("Generating audio...")
audio = generate_audio(text)
print("Audio generated, writing to file...")
end_time = time.time()
print(f"Processing time: {end_time - start_time} seconds")
write("test_output.wav", SAMPLE_RATE, audio)
print("File written successfully!")