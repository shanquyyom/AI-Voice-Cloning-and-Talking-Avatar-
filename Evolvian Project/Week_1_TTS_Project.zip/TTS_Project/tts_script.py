from gtts import gTTS
import os

# Yeh 2-minute ka Urdu text hai (~350 words)
text = """
Evolvian Softwares is an innovative technology company, building AI-powered solutions to transform ideas into reality
"""

# Language set karo: 'ur' for Urdu
language = 'ur'

# TTS object banayo
tts = gTTS(text=text, lang=language, slow=False)

# Audio file save karo
output_file = "output_audio.mp3"
tts.save(output_file)

# Confirm message
print(f"Audio file generated: {os.path.abspath(output_file)}")